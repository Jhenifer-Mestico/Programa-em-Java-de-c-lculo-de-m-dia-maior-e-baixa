package temperatura;
import javax.swing.*;

public class Temperatura {

    public static void main(String[] args) {

        float temperatura, soma, media; 
        float v[] = new float[7];
        int contador, acima, abaixo;
        
        soma = 0;
        
        for (contador = 1; contador < 7; contador++){
            
             temperatura = Float.parseFloat(
                 JOptionPane.showInputDialog (null, 
                 "Digite a " + contador + "\ntemperatura:", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
             
             v[contador] = v[contador] + temperatura;
        
             soma = soma + v[contador];
        }
        
        media = soma / 7;
        acima = 0;
        abaixo = 0;
        
        for (contador = 1; contador < 7; contador++){
        
        if(v[contador] > media){
            
                    acima = acima + 1;    
        }
        
        if (v[contador] < media){

                abaixo = abaixo + 1;
        }
        
    }
        JOptionPane.showMessageDialog (null, 
                 "Total de dias que a temperatura ficou acima da média:\n" + acima + "\nTotal de dias que a temperatura ficou abaixo da média:\n" + abaixo,
                 "Resultado", JOptionPane.INFORMATION_MESSAGE);   
    }
    
}